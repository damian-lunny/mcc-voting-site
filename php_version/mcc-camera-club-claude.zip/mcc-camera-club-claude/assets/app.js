// ============================================
// Maguiresbridge Camera Club - Main JS
// ============================================

// --- Accessibility Toggles ---
function applyStoredPrefs() {
    if (localStorage.getItem('mcc_contrast') === '1') {
        document.body.classList.add('high-contrast');
        const btn = document.getElementById('contrastToggle');
        if (btn) btn.innerHTML = '<i class="bi bi-circle-half"></i> Normal Contrast';
    }
    if (localStorage.getItem('mcc_larger_text') === '1') {
        document.body.classList.add('larger-text');
        const btn = document.getElementById('textSizeToggle');
        if (btn) btn.innerHTML = '<i class="bi bi-fonts"></i> Smaller Text';
    }
}

function toggleContrast() {
    const on = document.body.classList.toggle('high-contrast');
    localStorage.setItem('mcc_contrast', on ? '1' : '0');
    const btn = document.getElementById('contrastToggle');
    btn.innerHTML = on
        ? '<i class="bi bi-circle-half"></i> Normal Contrast'
        : '<i class="bi bi-circle-half"></i> High Contrast';
}

function toggleTextSize() {
    const on = document.body.classList.toggle('larger-text');
    localStorage.setItem('mcc_larger_text', on ? '1' : '0');
    const btn = document.getElementById('textSizeToggle');
    btn.innerHTML = on
        ? '<i class="bi bi-fonts"></i> Smaller Text'
        : '<i class="bi bi-fonts"></i> Larger Text';
}

// Apply on every page load
document.addEventListener('DOMContentLoaded', applyStoredPrefs);

// --- Vote page: duplicate check ---
function validateVoteForm(categoryIds) {
    for (const cat of categoryIds) {
        const inputs = document.querySelectorAll(`.photo-input-${cat}`);
        const vals = [];
        for (const inp of inputs) {
            const v = inp.value.trim();
            if (v !== '') {
                if (vals.includes(v)) {
                    alert(`Duplicate photo number "${v}" in the ${cat} category. Each photo can only appear once.`);
                    return false;
                }
                vals.push(v);
            }
        }
    }
    return true;
}

// --- Tally: live timestamp update ---
function updateTimestamp() {
    const el = document.getElementById('last-refresh');
    if (!el) return;
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    el.textContent = `${hh}:${mm}:${ss}`;
}

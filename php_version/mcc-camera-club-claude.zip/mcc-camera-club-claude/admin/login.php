<?php
require_once __DIR__ . '/../includes/template.php';
requireMemberLogin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $pw = trim($_POST['password'] ?? '');
    $correctPw = getSetting($pdo, 'admin_password', 'admin');
    if ($pw === $correctPw) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: /admin/index.php');
        exit;
    } else {
        $error = 'Incorrect admin password.';
    }
}

// If already admin, go straight to dashboard
if (isAdminLoggedIn()) {
    header('Location: /admin/index.php?section=statistics');
    exit;
}

renderHeader('Admin Login');
?>

<div class="pin-wrapper">
    <div class="pin-box">
        <i class="bi bi-shield-lock-fill logo-icon"></i>
        <h2>Admin Access</h2>
        <p class="sub">Enter the admin password to continue</p>

        <?php if ($error): ?>
            <div class="alert-mcc-danger mb-3">
                <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="/admin/login.php">
            <div class="mb-3">
                <input type="password" name="password" class="pin-input"
                       placeholder="Password" autocomplete="off" autofocus required>
            </div>
            <button type="submit" name="admin_login" class="btn btn-mcc w-100">
                <i class="bi bi-unlock-fill"></i> Login
            </button>
        </form>
    </div>
</div>

<?php renderFooter(); ?>

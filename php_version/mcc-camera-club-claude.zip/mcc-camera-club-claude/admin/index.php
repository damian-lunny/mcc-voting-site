<?php
require_once __DIR__ . '/../includes/template.php';
requireMemberLogin();

// Redirect to login if not admin
if (!isAdminLoggedIn()) {
    header('Location: /admin/login.php');
    exit;
}

$categories = ['beginner' => 'Beginner', 'intermediate' => 'Intermediate', 'advanced' => 'Advanced'];
$section    = $_GET['section'] ?? 'statistics';
$msg        = '';
$msgType    = 'success';

// -------------------------------------------------------
// Handle POST actions
// -------------------------------------------------------

// --- Site Access ---
if (isset($_POST['save_site_access'])) {
    setSetting($pdo, 'site_enabled', isset($_POST['site_enabled']) ? '1' : '0');
    if (!empty(trim($_POST['new_pin']))) {
        setSetting($pdo, 'site_pin', trim($_POST['new_pin']));
    }
    $msg = 'Site access settings saved.';
    $section = 'site_access';
}

// --- Category Control ---
if (isset($_POST['toggle_category'])) {
    $cat    = $_POST['category'] ?? '';
    $newVal = $_POST['new_value'] ?? '0';
    if (array_key_exists($cat, $categories)) {
        setSetting($pdo, "category_$cat", $newVal);
    }
    $msg = 'Category updated.';
    $section = 'category_control';
}

if (isset($_POST['toggle_all_categories'])) {
    $newVal = $_POST['all_value'] ?? '0';
    foreach ($categories as $catKey => $catLabel) {
        setSetting($pdo, "category_$catKey", $newVal);
    }
    $msg = 'All categories ' . ($newVal === '1' ? 'opened' : 'closed') . '.';
    $section = 'category_control';
}

// --- Photo Settings ---
if (isset($_POST['save_photo_settings'])) {
    $max = (int) ($_POST['max_photo_number'] ?? 30);
    if ($max < 1) $max = 1;
    setSetting($pdo, 'max_photo_number', (string) $max);
    $msg = 'Photo settings saved.';
    $section = 'photo_settings';
}

// --- Competition Management / Archive ---
if (isset($_POST['archive_competition'])) {
    $label = trim($_POST['competition_label'] ?? '');
    if ($label === '') {
        $msg = 'Please enter a label for this competition.';
        $msgType = 'danger';
        $section = 'competition';
    } else {
        $pointsMap = [1 => 5, 2 => 4, 3 => 3, 4 => 2, 5 => 1];
        foreach ($categories as $catKey => $catLabel) {
            // Tally votes
            $stmt = $pdo->prepare("SELECT photo_number, vote_position FROM votes WHERE category = ?");
            $stmt->execute([$catKey]);
            $rows   = $stmt->fetchAll();
            $scores = [];
            foreach ($rows as $row) {
                $pts = $pointsMap[$row['vote_position']] ?? 0;
                $pn  = $row['photo_number'];
                $scores[$pn] = ($scores[$pn] ?? 0) + $pts;
            }
            foreach ($scores as $photoNum => $pts) {
                $ins = $pdo->prepare("INSERT INTO archived_results (week_label, category, photo_number, vote_count) VALUES (?, ?, ?, ?)");
                $ins->execute([$label, $catKey, $photoNum, $pts]);
            }
            // Clear votes for this category
            $pdo->prepare("DELETE FROM votes WHERE category = ?")->execute([$catKey]);
        }
        setSetting($pdo, 'competition_label', $label);
        $msg = "Competition \"$label\" archived and votes cleared.";
        $section = 'competition';
    }
}

// --- Admin Password ---
if (isset($_POST['save_admin_password'])) {
    $newPw  = trim($_POST['new_password'] ?? '');
    $confPw = trim($_POST['confirm_password'] ?? '');
    if ($newPw === '') {
        $msg = 'Password cannot be empty.';
        $msgType = 'danger';
    } elseif ($newPw !== $confPw) {
        $msg = 'Passwords do not match.';
        $msgType = 'danger';
    } else {
        setSetting($pdo, 'admin_password', $newPw);
        $msg = 'Admin password updated.';
    }
    $section = 'admin_password';
}

// --- Delete Archive ---
if (isset($_POST['delete_archive'])) {
    $label = trim($_POST['archive_label'] ?? '');
    $stmt  = $pdo->prepare("DELETE FROM archived_results WHERE week_label = ?");
    $stmt->execute([$label]);
    $msg = "Archive \"$label\" deleted.";
    $section = 'archives';
}

// --- Set Date/Time ---
if (isset($_POST['set_datetime'])) {
    $date = trim($_POST['date_val'] ?? '');
    $time = trim($_POST['time_val'] ?? '');
    if (preg_match('/^\d{2}-\d{2}-\d{4}$/', $date) && preg_match('/^\d{2}:\d{2}$/', $time)) {
        // Convert dd-mm-yyyy → yyyy-mm-dd for date command
        [$dd, $mm, $yyyy] = explode('-', $date);
        $dateForCmd = "$yyyy-$mm-$dd $time:00";
        $escaped    = escapeshellarg($dateForCmd);
        exec("sudo date -s $escaped 2>&1", $output, $retCode);
        $msg = $retCode === 0 ? 'Date and time set successfully.' : 'Failed to set date/time. Check sudo permissions.';
    } else {
        $msg     = 'Invalid date or time format.';
        $msgType = 'danger';
    }
    $section = 'datetime';
}

// --- Shutdown ---
if (isset($_POST['confirm_shutdown'])) {
    exec('sudo halt 2>&1');
    $msg     = 'Shutdown command sent.';
    $section = 'shutdown';
}

// -------------------------------------------------------
// Fetch data for display
// -------------------------------------------------------
$totalVotes = $pdo->query("SELECT COUNT(*) FROM votes")->fetchColumn();

$archives = $pdo->query(
    "SELECT week_label, MIN(archived_date) as adate, COUNT(*) as entries FROM archived_results GROUP BY week_label ORDER BY adate DESC"
)->fetchAll();

$catStatuses = [];
foreach ($categories as $catKey => $catLabel) {
    $catStatuses[$catKey] = getSetting($pdo, "category_$catKey", '0') === '1';
}

$siteEnabled     = getSetting($pdo, 'site_enabled', '1');
$currentPin      = getSetting($pdo, 'site_pin', '1234');
$maxPhotoNumber  = getSetting($pdo, 'max_photo_number', '30');
$competitionLabel = getSetting($pdo, 'competition_label', '');

// Category vote counts
$catVoteCounts = [];
foreach ($categories as $catKey => $catLabel) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM votes WHERE category = ?");
    $stmt->execute([$catKey]);
    $catVoteCounts[$catKey] = $stmt->fetchColumn();
}

$adminSections = [
    'statistics'       => ['icon' => 'bi-graph-up',       'label' => 'Statistics'],
    'site_access'      => ['icon' => 'bi-key-fill',        'label' => 'Site Access'],
    'category_control' => ['icon' => 'bi-toggles',         'label' => 'Category Control'],
    'photo_settings'   => ['icon' => 'bi-image',           'label' => 'Photo Settings'],
    'competition'      => ['icon' => 'bi-trophy-fill',     'label' => 'Competition'],
    'admin_password'   => ['icon' => 'bi-lock-fill',       'label' => 'Admin Password'],
    'archives'         => ['icon' => 'bi-archive-fill',    'label' => 'Archives'],
    'datetime'         => ['icon' => 'bi-clock-fill',      'label' => 'Set Date/Time'],
    'shutdown'         => ['icon' => 'bi-power',           'label' => 'Shutdown'],
];

renderHeader('Admin');
?>

<div class="d-flex align-items-baseline gap-3 mb-1">
    <h1 class="page-title"><i class="bi bi-shield-lock-fill text-mcc-accent"></i> Admin Panel</h1>
</div>
<p class="page-subtitle">Manage competition settings and site access.</p>

<?php if ($msg): ?>
    <div class="alert-mcc-<?= $msgType === 'danger' ? 'danger' : 'success' ?> mb-3">
        <i class="bi bi-<?= $msgType === 'danger' ? 'exclamation-triangle' : 'check-circle' ?>-fill"></i>
        <?= htmlspecialchars($msg) ?>
    </div>
<?php endif; ?>

<!-- Admin nav grid -->
<div class="admin-nav-grid">
    <?php foreach ($adminSections as $key => $info): ?>
        <a href="/admin/index.php?section=<?= $key ?>"
           class="admin-nav-btn <?= $section === $key ? 'active' : '' ?>">
            <i class="bi <?= $info['icon'] ?>"></i>
            <span><?= $info['label'] ?></span>
        </a>
    <?php endforeach; ?>
</div>

<!-- ============ STATISTICS ============ -->
<?php if ($section === 'statistics'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-graph-up"></i> Statistics</div>
    <div class="row g-3">
        <div class="col-6 col-md-3">
            <div class="stat-box">
                <div class="stat-num"><?= $totalVotes ?></div>
                <div class="stat-label">Total Votes Cast</div>
            </div>
        </div>
        <?php foreach ($categories as $catKey => $catLabel): ?>
        <div class="col-6 col-md-3">
            <div class="stat-box">
                <div class="stat-num"><?= $catVoteCounts[$catKey] ?></div>
                <div class="stat-label"><?= $catLabel ?> Votes</div>
            </div>
        </div>
        <?php endforeach; ?>
        <div class="col-6 col-md-3">
            <div class="stat-box">
                <div class="stat-num"><?= count($archives) ?></div>
                <div class="stat-label">Archived Competitions</div>
            </div>
        </div>
    </div>
</div>

<!-- ============ SITE ACCESS ============ -->
<?php elseif ($section === 'site_access'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-key-fill"></i> Site Access</div>
    <form method="POST" action="/admin/index.php?section=site_access">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Site Status</label>
                <div class="form-check form-switch mt-1">
                    <input class="form-check-input" type="checkbox" name="site_enabled" id="siteEnabled"
                           <?= $siteEnabled === '1' ? 'checked' : '' ?>>
                    <label class="form-check-label text-mcc-muted" for="siteEnabled">
                        Voting site enabled
                    </label>
                </div>
            </div>
            <div class="col-md-6">
                <label class="form-label">Current PIN: <strong class="text-mcc-accent"><?= htmlspecialchars($currentPin) ?></strong></label>
                <input type="text" name="new_pin" class="form-control" placeholder="Enter new PIN (leave blank to keep current)"
                       autocomplete="off" maxlength="20">
                <div class="form-text text-mcc-muted">Leave blank to keep the existing PIN.</div>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" name="save_site_access" class="btn btn-mcc">
                <i class="bi bi-floppy-fill"></i> Save Settings
            </button>
        </div>
    </form>
</div>

<!-- ============ CATEGORY CONTROL ============ -->
<?php elseif ($section === 'category_control'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-toggles"></i> Category Control</div>

    <div class="d-flex gap-2 mb-3">
        <form method="POST" action="/admin/index.php?section=category_control">
            <input type="hidden" name="toggle_all_categories" value="1">
            <input type="hidden" name="all_value" value="1">
            <button type="submit" class="btn btn-mcc">
                <i class="bi bi-play-circle-fill"></i> Open All
            </button>
        </form>
        <form method="POST" action="/admin/index.php?section=category_control">
            <input type="hidden" name="toggle_all_categories" value="1">
            <input type="hidden" name="all_value" value="0">
            <button type="submit" class="btn btn-mcc-danger">
                <i class="bi bi-stop-circle-fill"></i> Close All
            </button>
        </form>
    </div>

    <div class="row g-3">
        <?php foreach ($categories as $catKey => $catLabel):
            $isOpen = $catStatuses[$catKey];
        ?>
        <div class="col-md-4">
            <div class="mcc-card" style="margin-bottom:0; border-color: <?= $isOpen ? 'var(--mcc-success)' : 'var(--mcc-danger)' ?>;">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <strong class="text-mcc-accent" style="font-family:var(--font-head); font-size:1.1rem; text-transform:uppercase;">
                        <?= htmlspecialchars($catLabel) ?>
                    </strong>
                    <span class="badge" style="background: <?= $isOpen ? 'var(--mcc-success)' : 'var(--mcc-danger)' ?>; color:#fff;">
                        <?= $isOpen ? 'OPEN' : 'CLOSED' ?>
                    </span>
                </div>
                <form method="POST" action="/admin/index.php?section=category_control">
                    <input type="hidden" name="toggle_category" value="1">
                    <input type="hidden" name="category" value="<?= $catKey ?>">
                    <input type="hidden" name="new_value" value="<?= $isOpen ? '0' : '1' ?>">
                    <button type="submit" class="btn w-100 category-toggle-btn <?= $isOpen ? 'btn-mcc-danger' : 'btn-mcc' ?>">
                        <?php if ($isOpen): ?>
                            <i class="bi bi-stop-circle-fill"></i> Close Voting
                        <?php else: ?>
                            <i class="bi bi-play-circle-fill"></i> Open Voting
                        <?php endif; ?>
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- ============ PHOTO SETTINGS ============ -->
<?php elseif ($section === 'photo_settings'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-image"></i> Photo Settings</div>
    <form method="POST" action="/admin/index.php?section=photo_settings">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Maximum Photo Number</label>
                <input type="number" name="max_photo_number" class="form-control"
                       value="<?= htmlspecialchars($maxPhotoNumber) ?>" min="1" max="999">
                <div class="form-text text-mcc-muted">Votes above this number will be rejected. Default: 30.</div>
            </div>
            <div class="col-md-3">
                <button type="submit" name="save_photo_settings" class="btn btn-mcc">
                    <i class="bi bi-floppy-fill"></i> Save
                </button>
            </div>
        </div>
    </form>
</div>

<!-- ============ COMPETITION MANAGEMENT ============ -->
<?php elseif ($section === 'competition'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-trophy-fill"></i> Competition Management</div>
    <p class="text-mcc-muted" style="font-size:0.9rem;">
        Archiving a competition will save all current votes into the Archive, then clear all votes. 
        This action cannot be undone.
    </p>
    <form method="POST" action="/admin/index.php?section=competition"
          onsubmit="return confirm('Archive this competition and clear all current votes? This cannot be undone.');">
        <div class="row g-3 align-items-end">
            <div class="col-md-6">
                <label class="form-label">Competition Label</label>
                <input type="text" name="competition_label" class="form-control"
                       placeholder="e.g. Week 1 — Landscape"
                       value="<?= htmlspecialchars($competitionLabel) ?>" required>
                <div class="form-text text-mcc-muted">This label will identify the competition in the Archive.</div>
            </div>
            <div class="col-md-4">
                <button type="submit" name="archive_competition" class="btn btn-mcc">
                    <i class="bi bi-archive-fill"></i> Archive &amp; Clear Votes
                </button>
            </div>
        </div>
    </form>

    <?php
    // Show current vote summary
    $pointsMap = [1 => 5, 2 => 4, 3 => 3, 4 => 2, 5 => 1];
    $hasVotes  = false;
    foreach ($categories as $catKey => $catLabel) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM votes WHERE category = ?");
        $stmt->execute([$catKey]);
        if ($stmt->fetchColumn() > 0) { $hasVotes = true; break; }
    }
    ?>
    <?php if ($hasVotes): ?>
        <hr class="divider">
        <p class="text-mcc-muted" style="font-size:0.85rem; margin-bottom:0.5rem;">Current votes to be archived:</p>
        <div class="row g-2">
        <?php foreach ($categories as $catKey => $catLabel):
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM votes WHERE category = ?");
            $stmt->execute([$catKey]);
            $cnt = $stmt->fetchColumn();
        ?>
            <div class="col-md-4">
                <div class="stat-box">
                    <div class="stat-num"><?= $cnt ?></div>
                    <div class="stat-label"><?= $catLabel ?></div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert-mcc mt-3"><i class="bi bi-info-circle"></i> No votes currently recorded.</div>
    <?php endif; ?>
</div>

<!-- ============ ADMIN PASSWORD ============ -->
<?php elseif ($section === 'admin_password'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-lock-fill"></i> Admin Password</div>
    <form method="POST" action="/admin/index.php?section=admin_password">
        <div class="row g-3">
            <div class="col-md-5">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control"
                       placeholder="Enter new password" autocomplete="new-password" required>
            </div>
            <div class="col-md-5">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control"
                       placeholder="Repeat new password" autocomplete="new-password" required>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" name="save_admin_password" class="btn btn-mcc">
                <i class="bi bi-floppy-fill"></i> Update Password
            </button>
        </div>
    </form>
</div>

<!-- ============ ARCHIVES ============ -->
<?php elseif ($section === 'archives'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-archive-fill"></i> Archives</div>
    <?php if (empty($archives)): ?>
        <p class="text-mcc-muted">No archived competitions yet.</p>
    <?php else: ?>
        <?php foreach ($archives as $arc): ?>
            <div class="archive-list-item">
                <div>
                    <div class="archive-name"><?= htmlspecialchars($arc['week_label']) ?></div>
                    <div class="archive-date">
                        <i class="bi bi-calendar3"></i> <?= date('d M Y', strtotime($arc['adate'])) ?>
                        &mdash; <?= $arc['entries'] ?> entries
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <a href="/archive.php?week=<?= urlencode($arc['week_label']) ?>" class="btn btn-mcc-outline btn-sm">
                        <i class="bi bi-eye"></i> View
                    </a>
                    <form method="POST" action="/admin/index.php?section=archives"
                          onsubmit="return confirm('Delete archive \'<?= htmlspecialchars(addslashes($arc['week_label'])) ?>\'? This cannot be undone.');">
                        <input type="hidden" name="delete_archive" value="1">
                        <input type="hidden" name="archive_label" value="<?= htmlspecialchars($arc['week_label']) ?>">
                        <button type="submit" class="btn btn-mcc-danger btn-sm">
                            <i class="bi bi-trash3-fill"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- ============ SET DATE/TIME ============ -->
<?php elseif ($section === 'datetime'): ?>
<div class="mcc-card">
    <div class="mcc-card-title"><i class="bi bi-clock-fill"></i> Set Date &amp; Time</div>
    <p class="text-mcc-muted" style="font-size:0.9rem;">
        Sets the system date and time on the Raspberry Pi using <code>sudo date -s</code>.
        Ensure the web server user has appropriate sudo permissions.
    </p>
    <form method="POST" action="/admin/index.php?section=datetime">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Date <span class="text-mcc-muted">(dd-mm-yyyy)</span></label>
                <input type="text" name="date_val" class="form-control"
                       placeholder="31-12-2024"
                       pattern="\d{2}-\d{2}-\d{4}"
                       value="<?= date('d-m-Y') ?>"
                       required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Time <span class="text-mcc-muted">(hh:mm)</span></label>
                <input type="text" name="time_val" class="form-control"
                       placeholder="19:30"
                       pattern="\d{2}:\d{2}"
                       value="<?= date('H:i') ?>"
                       required>
            </div>
            <div class="col-md-3">
                <button type="submit" name="set_datetime" class="btn btn-mcc">
                    <i class="bi bi-clock-history"></i> Set Date &amp; Time
                </button>
            </div>
        </div>
    </form>
</div>

<!-- ============ SHUTDOWN ============ -->
<?php elseif ($section === 'shutdown'): ?>
<div class="mcc-card" style="border-color: var(--mcc-danger);">
    <div class="mcc-card-title" style="color: var(--mcc-danger);">
        <i class="bi bi-power"></i> Shutdown Raspberry Pi
    </div>
    <div class="alert-mcc-danger mb-3">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <strong>Warning:</strong> This will immediately shut down the Raspberry Pi. 
        All users will lose access to the site until it is manually powered back on.
    </div>
    <form method="POST" action="/admin/index.php?section=shutdown"
          onsubmit="return confirm('Are you sure you want to shut down the Raspberry Pi? The site will go offline immediately.');">
        <button type="submit" name="confirm_shutdown" class="btn btn-mcc-danger">
            <i class="bi bi-power"></i> Shut Down Now
        </button>
    </form>
</div>
<?php endif; ?>

<?php renderFooter(); ?>

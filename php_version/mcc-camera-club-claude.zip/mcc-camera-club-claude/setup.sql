-- Maguiresbridge Camera Club Database Setup
-- Run this to create tables and seed default settings

CREATE TABLE IF NOT EXISTS votes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(50) NOT NULL,
    photo_number INT NOT NULL,
    vote_position INT DEFAULT 1,
    voter_session VARCHAR(64),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
    `key` VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS archived_results (
    id INT PRIMARY KEY AUTO_INCREMENT,
    week_label VARCHAR(200) NOT NULL,
    category VARCHAR(50) NOT NULL,
    photo_number INT NOT NULL,
    vote_count INT NOT NULL,
    photographer_name VARCHAR(200),
    photo_title VARCHAR(200),
    highly_commended_1 INT DEFAULT NULL,
    highly_commended_1_name VARCHAR(200),
    highly_commended_1_title VARCHAR(200),
    highly_commended_2 INT DEFAULT NULL,
    highly_commended_2_name VARCHAR(200),
    highly_commended_2_title VARCHAR(200),
    commended INT DEFAULT NULL,
    commended_name VARCHAR(200),
    commended_title VARCHAR(200),
    archived_date DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Default settings
INSERT IGNORE INTO settings (`key`, value) VALUES
('site_pin', '1234'),
('site_enabled', '1'),
('admin_password', 'admin'),
('category_beginner', '0'),
('category_intermediate', '0'),
('category_advanced', '0'),
('max_photo_number', '30'),
('competition_label', 'Week 1');

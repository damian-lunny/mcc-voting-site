-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2026 at 10:35 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcc`
--

-- --------------------------------------------------------

--
-- Table structure for table `archived_results`
--

CREATE TABLE `archived_results` (
  `id` int(11) NOT NULL,
  `week_label` varchar(200) NOT NULL,
  `category` varchar(50) NOT NULL,
  `photo_number` int(11) NOT NULL,
  `vote_count` int(11) NOT NULL,
  `photographer_name` varchar(200) DEFAULT NULL,
  `photo_title` varchar(200) DEFAULT NULL,
  `highly_commended_1` int(11) DEFAULT NULL,
  `highly_commended_1_name` varchar(200) DEFAULT NULL,
  `highly_commended_1_title` varchar(200) DEFAULT NULL,
  `highly_commended_2` int(11) DEFAULT NULL,
  `highly_commended_2_name` varchar(200) DEFAULT NULL,
  `highly_commended_2_title` varchar(200) DEFAULT NULL,
  `commended` int(11) DEFAULT NULL,
  `commended_name` varchar(200) DEFAULT NULL,
  `commended_title` varchar(200) DEFAULT NULL,
  `archived_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`) VALUES
('admin_password', 'admin'),
('category_advanced', '0'),
('category_beginner', '0'),
('category_intermediate', '0'),
('competition_label', 'Week 1'),
('max_photo_number', '30'),
('site_enabled', '1'),
('site_pin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `photo_number` int(11) NOT NULL,
  `vote_position` int(11) DEFAULT 1,
  `voter_session` varchar(64) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archived_results`
--
ALTER TABLE `archived_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archived_results`
--
ALTER TABLE `archived_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

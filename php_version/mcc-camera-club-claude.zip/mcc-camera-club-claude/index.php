<?php
require_once __DIR__ . '/includes/template.php';

// Already logged in? Go to vote page
if (isMemberLoggedIn()) {
    header('Location: vote.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredPin = trim($_POST['pin'] ?? '');

    // Check site is enabled
    $siteEnabled = getSetting($pdo, 'site_enabled', '1');
    if ($siteEnabled !== '1') {
        $error = 'Voting is currently disabled. Please check back later.';
    } else {
        $correctPin = getSetting($pdo, 'site_pin', '1234');
        if ($enteredPin === $correctPin) {
            $_SESSION['member_logged_in'] = true;
            header('Location: vote.php');
            exit;
        } else {
            $error = 'Incorrect PIN. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MCC Voting | Enter PIN</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="/bootstrap-5.3.8-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/bootstrap-icons-1.13.1/bootstrap-icons.min.css">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div id="top-bar">
    <div class="container-fluid d-flex align-items-center justify-content-between px-3 py-2">
        <div class="brand d-flex align-items-center gap-2">
            <i class="bi bi-camera2 brand-icon"></i>
            <span class="brand-name">Maguiresbridge<span class="brand-accent"> Camera Club</span></span>
        </div>
        <div class="access-tools d-flex gap-2">
            <button class="btn btn-sm btn-outline-secondary" id="contrastToggle" onclick="toggleContrast()">
                <i class="bi bi-circle-half"></i> High Contrast
            </button>
            <button class="btn btn-sm btn-outline-secondary" id="textSizeToggle" onclick="toggleTextSize()">
                <i class="bi bi-fonts"></i> Larger Text
            </button>
        </div>
    </div>
</div>

<main class="container py-4">
    <div class="pin-wrapper">
        <div class="pin-box">
            <i class="bi bi-camera2 logo-icon"></i>
            <h2>Competition Voting</h2>
            <p class="sub">Enter your member PIN to access voting</p>

            <?php if ($error): ?>
                <div class="alert-mcc-danger mb-3">
                    <i class="bi bi-exclamation-triangle-fill"></i> <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php">
                <div class="mb-3">
                    <input
                        type="password"
                        name="pin"
                        class="pin-input"
                        placeholder="&#9679;&#9679;&#9679;&#9679;"
                        maxlength="20"
                        autocomplete="off"
                        autofocus
                        required
                    >
                </div>
                <button type="submit" class="btn btn-mcc w-100">
                    <i class="bi bi-unlock-fill"></i> Enter
                </button>
            </form>
        </div>
    </div>
</main>

<footer class="py-3 mt-auto">
    <div class="container text-center footer-text">
        <small><i class="bi bi-camera2"></i> Maguiresbridge Camera Club &mdash; Competition Voting System</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/app.js"></script>
</body>
</html>

<?php
require_once __DIR__ . '/includes/template.php';
requireMemberLogin();

$categories  = ['beginner' => 'Beginner', 'intermediate' => 'Intermediate', 'advanced' => 'Advanced'];
$pointsMap   = [1 => 5, 2 => 4, 3 => 3, 4 => 2, 5 => 1];

// Handle admin clear all votes
if (isAdminLoggedIn() && isset($_POST['clear_votes'])) {
    foreach ($categories as $catKey => $catLabel) {
        if (getSetting($pdo, "category_$catKey", '0') === '1') {
            $pdo->prepare("DELETE FROM votes WHERE category = ?")->execute([$catKey]);
        }
    }
    header('Location: /tally.php?cleared=1');
    exit;
}

$cleared = isset($_GET['cleared']);

// Build tally per category
$tallies = [];
foreach ($categories as $catKey => $catLabel) {
    if (getSetting($pdo, "category_$catKey", '0') !== '1') continue;

    $stmt = $pdo->prepare("SELECT photo_number, vote_position FROM votes WHERE category = ?");
    $stmt->execute([$catKey]);
    $rows = $stmt->fetchAll();

    $scores = [];
    foreach ($rows as $row) {
        $pts = $pointsMap[$row['vote_position']] ?? 0;
        $pn  = $row['photo_number'];
        $scores[$pn] = ($scores[$pn] ?? 0) + $pts;
    }
    arsort($scores);
    $tallies[$catKey] = ['label' => $catLabel, 'scores' => $scores];
}

$hasAny = array_sum(array_map(fn($t) => count($t['scores']), $tallies)) > 0;

renderHeader('Live Tally', '<meta http-equiv="refresh" content="10">');
?>

<div class="d-flex align-items-baseline gap-3 mb-1">
    <h1 class="page-title"><i class="bi bi-bar-chart-fill text-mcc-accent"></i> Live Tally</h1>
</div>
<p class="page-subtitle">Current competition results — updated automatically every 10 seconds.</p>

<?php if ($cleared): ?>
    <div class="alert-mcc-success mb-3"><i class="bi bi-check-circle-fill"></i> All votes cleared.</div>
<?php endif; ?>

<div class="tally-refresh-info">
    Last refreshed: <strong id="last-refresh">--:--:--</strong>
</div>

<?php if (empty($tallies) && !$hasAny): ?>
    <div class="mcc-card text-center py-4">
        <i class="bi bi-hourglass-split" style="font-size:2.5rem; color:var(--mcc-text-muted);"></i>
        <p class="mt-2 text-mcc-muted">No categories are currently active, or no votes have been cast yet.</p>
    </div>
<?php else: ?>
    <?php foreach ($tallies as $catKey => $tally): ?>
        <div class="mcc-card">
            <div class="mcc-card-title">
                <i class="bi bi-tag-fill"></i> <?= htmlspecialchars($tally['label']) ?>
            </div>

            <?php if (empty($tally['scores'])): ?>
                <p class="text-mcc-muted"><i class="bi bi-inbox"></i> No votes yet in this category.</p>
            <?php else:
                $max  = max($tally['scores']);
                $rank = 0;
                foreach ($tally['scores'] as $photoNum => $pts):
                    $rank++;
                    $pct       = $max > 0 ? round(($pts / $max) * 100) : 0;
                    $rankClass = $rank <= 3 ? "rank-$rank" : '';
            ?>
                <div class="tally-bar-wrap <?= $rankClass ?>">
                    <div class="tally-label">
                        <span>
                            <span class="photo-num-badge">Photo #<?= htmlspecialchars($photoNum) ?></span>
                        </span>
                        <span class="tally-points"><?= $pts ?> pt<?= $pts !== 1 ? 's' : '' ?></span>
                    </div>
                    <div class="tally-bar-bg">
                        <div class="tally-bar-fill" style="width: <?= $pct ?>%;">
                            <?= $pct >= 15 ? "Photo #$photoNum" : '' ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php if (isAdminLoggedIn()): ?>
    <hr class="divider">
    <div class="mcc-card">
        <div class="mcc-card-title"><i class="bi bi-trash3-fill"></i> Admin Controls</div>
        <p class="text-mcc-muted" style="font-size:0.9rem;">This will clear all votes for all currently enabled categories.</p>
        <form method="POST" action="/tally.php" onsubmit="return confirm('Are you sure you want to clear ALL votes for enabled categories? This cannot be undone.');">
            <button type="submit" name="clear_votes" class="btn btn-mcc-danger">
                <i class="bi bi-trash3-fill"></i> Clear All Votes
            </button>
        </form>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    updateTimestamp();
});
</script>

<?php renderFooter(); ?>

<?php
require_once __DIR__ . '/includes/template.php';
requireMemberLogin();

$categories = ['beginner' => 'Beginner', 'intermediate' => 'Intermediate', 'advanced' => 'Advanced'];
$maxPhoto = (int) getSetting($pdo, 'max_photo_number', '30');
$positions = [1 => '1st', 2 => '2nd', 3 => '3rd', 4 => '4th', 5 => '5th'];
$points    = [1 => 5, 2 => 4, 3 => 3, 4 => 2, 5 => 1];

$successMsg = '';
$errorMsg   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $voterSession = session_id();
    $hasAnyVote   = false;
    $errors       = [];

    foreach ($categories as $catKey => $catLabel) {
        if (getSetting($pdo, "category_$catKey", '0') !== '1') continue;

        $submitted = [];
        for ($pos = 1; $pos <= 5; $pos++) {
            $val = trim($_POST["{$catKey}_pos{$pos}"] ?? '');
            if ($val === '') continue;

            $num = (int) $val;
            if ($num < 1 || $num > $maxPhoto) {
                $errors[] = "$catLabel: Photo number $val is out of range (1–$maxPhoto).";
                continue;
            }
            if (in_array($num, $submitted)) {
                $errors[] = "$catLabel: Photo number $num entered more than once.";
                continue;
            }
            $submitted[] = $num;
        }
    }

    if (empty($errors)) {
        // Delete previous votes from this session for enabled categories
        foreach ($categories as $catKey => $catLabel) {
            if (getSetting($pdo, "category_$catKey", '0') !== '1') continue;

            $stmt = $pdo->prepare("DELETE FROM votes WHERE category = ? AND voter_session = ?");
            $stmt->execute([$catKey, session_id()]);

            for ($pos = 1; $pos <= 5; $pos++) {
                $val = trim($_POST["{$catKey}_pos{$pos}"] ?? '');
                if ($val === '') continue;
                $num = (int) $val;
                if ($num < 1 || $num > $maxPhoto) continue;

                $ins = $pdo->prepare("INSERT INTO votes (category, photo_number, vote_position, voter_session) VALUES (?, ?, ?, ?)");
                $ins->execute([$catKey, $num, $pos, session_id()]);
                $hasAnyVote = true;
            }
        }
        $successMsg = $hasAnyVote ? 'Your votes have been saved successfully!' : 'No votes were submitted (all fields were empty).';
    } else {
        $errorMsg = implode('<br>', array_map('htmlspecialchars', $errors));
    }
}

// Fetch existing votes for this session
$existingVotes = [];
foreach ($categories as $catKey => $catLabel) {
    $stmt = $pdo->prepare("SELECT photo_number, vote_position FROM votes WHERE category = ? AND voter_session = ? ORDER BY vote_position");
    $stmt->execute([$catKey, session_id()]);
    foreach ($stmt->fetchAll() as $row) {
        $existingVotes[$catKey][$row['vote_position']] = $row['photo_number'];
    }
}

renderHeader('Vote');
?>

<div class="d-flex align-items-baseline gap-3 mb-1">
    <h1 class="page-title"><i class="bi bi-check2-square text-mcc-accent"></i> Cast Your Votes</h1>
</div>
<p class="page-subtitle">Award points to your favourite photographs. Up to 5 choices per category.</p>

<?php if ($successMsg): ?>
    <div class="alert-mcc-success mb-3"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($successMsg) ?></div>
<?php endif; ?>
<?php if ($errorMsg): ?>
    <div class="alert-mcc-danger mb-3"><i class="bi bi-exclamation-triangle-fill"></i> <?= $errorMsg ?></div>
<?php endif; ?>

<form method="POST" action="/vote.php" onsubmit="return validateVoteForm(<?= json_encode(array_keys($categories)) ?>)">
<?php foreach ($categories as $catKey => $catLabel):
    $enabled = getSetting($pdo, "category_$catKey", '0') === '1';
?>
    <div class="mcc-card vote-category">
        <div class="mcc-card-title">
            <i class="bi bi-tag-fill"></i> <?= htmlspecialchars($catLabel) ?>
        </div>

        <?php if (!$enabled): ?>
            <div class="category-closed-banner">
                <i class="bi bi-lock-fill"></i>
                Voting in this category is currently closed.
            </div>
        <?php else: ?>
            <p class="text-mcc-muted" style="font-size:0.85rem; margin-bottom:1rem;">
                Enter the photo number for each position. Leave blank if you have fewer than 5 choices.
            </p>
            <?php for ($pos = 1; $pos <= 5; $pos++):
                $posClasses = ['', 'pos-1', 'pos-2', 'pos-3', 'pos-4', 'pos-5'];
                $existing   = $existingVotes[$catKey][$pos] ?? '';
            ?>
            <div class="photo-row">
                <span class="position-badge <?= $posClasses[$pos] ?>"><?= $pos ?></span>
                <label><?= $positions[$pos] ?> &mdash; <span class="points-label"><?= $points[$pos] ?> pts</span></label>
                <input
                    type="number"
                    name="<?= $catKey ?>_pos<?= $pos ?>"
                    class="photo-number-input photo-input-<?= $catKey ?>"
                    min="1"
                    max="<?= $maxPhoto ?>"
                    placeholder="Photo #"
                    value="<?= $existing ? htmlspecialchars($existing) : '' ?>"
                >
            </div>
            <?php endfor; ?>
        <?php endif; ?>
    </div>
<?php endforeach; ?>

    <div class="d-flex gap-2">
        <button type="submit" class="btn btn-mcc px-4">
            <i class="bi bi-send-fill"></i> Submit Votes
        </button>
        <a href="/tally.php" class="btn btn-mcc-outline">
            <i class="bi bi-bar-chart-fill"></i> View Live Tally
        </a>
    </div>
</form>

<?php renderFooter(); ?>

<?php
require_once __DIR__ . '/includes/template.php';
requireMemberLogin();

$categories = ['beginner' => 'Beginner', 'intermediate' => 'Intermediate', 'advanced' => 'Advanced'];

$msg = '';
$msgType = 'success';

// Save photographer/title for a photo in an archive
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_photo'])) {
    $archiveId    = (int) ($_POST['archive_id'] ?? 0);
    $weekLabel    = trim($_POST['week_label'] ?? '');
    $catKey       = trim($_POST['category'] ?? '');
    $photoNum     = (int) ($_POST['photo_number'] ?? 0);
    $photographer = trim($_POST['photographer_name'] ?? '');
    $title        = trim($_POST['photo_title'] ?? '');

    $stmt = $pdo->prepare("UPDATE archived_results SET photographer_name = ?, photo_title = ? WHERE id = ?");
    $stmt->execute([$photographer, $title, $archiveId]);
    $msg = 'Photo details saved.';
}

// Save honours (HC/Commended) for a week+category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_honours'])) {
    $weekLabel = trim($_POST['week_label'] ?? '');
    $catKey    = trim($_POST['category'] ?? '');

    $hc1       = (int) ($_POST['hc1_num'] ?? 0) ?: null;
    $hc1name   = trim($_POST['hc1_name'] ?? '');
    $hc1title  = trim($_POST['hc1_title'] ?? '');
    $hc2       = (int) ($_POST['hc2_num'] ?? 0) ?: null;
    $hc2name   = trim($_POST['hc2_name'] ?? '');
    $hc2title  = trim($_POST['hc2_title'] ?? '');
    $com       = (int) ($_POST['com_num'] ?? 0) ?: null;
    $comname   = trim($_POST['com_name'] ?? '');
    $comtitle  = trim($_POST['com_title'] ?? '');

    // Update all rows in this week+category with the honours
    $stmt = $pdo->prepare("UPDATE archived_results SET
        highly_commended_1 = ?, highly_commended_1_name = ?, highly_commended_1_title = ?,
        highly_commended_2 = ?, highly_commended_2_name = ?, highly_commended_2_title = ?,
        commended = ?, commended_name = ?, commended_title = ?
        WHERE week_label = ? AND category = ?");
    $stmt->execute([
        $hc1, $hc1name, $hc1title,
        $hc2, $hc2name, $hc2title,
        $com, $comname, $comtitle,
        $weekLabel, $catKey
    ]);
    $msg = 'Honours saved.';
}

// Get list of distinct week labels
$weeks = $pdo->query("SELECT DISTINCT week_label, MIN(archived_date) as adate FROM archived_results GROUP BY week_label ORDER BY adate DESC")->fetchAll();

$selectedWeek = $_GET['week'] ?? null;
$weekResults  = [];
$honoursData  = [];

if ($selectedWeek) {
    foreach ($categories as $catKey => $catLabel) {
        $stmt = $pdo->prepare("SELECT * FROM archived_results WHERE week_label = ? AND category = ? ORDER BY vote_count DESC");
        $stmt->execute([$selectedWeek, $catKey]);
        $rows = $stmt->fetchAll();
        if ($rows) {
            $weekResults[$catKey] = ['label' => $catLabel, 'photos' => $rows];
            // Honours come from the first row (same for all rows in this week+cat)
            $honoursData[$catKey] = $rows[0];
        }
    }
}

renderHeader('Archive');
?>

<div class="d-flex align-items-baseline gap-3 mb-1">
    <h1 class="page-title"><i class="bi bi-archive-fill text-mcc-accent"></i> Archive</h1>
</div>
<p class="page-subtitle">Browse past competition results.</p>

<?php if ($msg): ?>
    <div class="alert-mcc-success mb-3"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<?php if (empty($weeks)): ?>
    <div class="mcc-card text-center py-4">
        <i class="bi bi-archive" style="font-size:2.5rem; color:var(--mcc-text-muted);"></i>
        <p class="mt-2 text-mcc-muted">No archived competitions yet.</p>
    </div>
<?php else: ?>
    <!-- Archive list -->
    <div class="mcc-card">
        <div class="mcc-card-title"><i class="bi bi-list-ul"></i> Competitions</div>
        <?php foreach ($weeks as $w): ?>
            <div class="archive-list-item">
                <div>
                    <div class="archive-name"><?= htmlspecialchars($w['week_label']) ?></div>
                    <div class="archive-date"><i class="bi bi-calendar3"></i> <?= date('d M Y', strtotime($w['adate'])) ?></div>
                </div>
                <a href="/archive.php?week=<?= urlencode($w['week_label']) ?>" class="btn btn-mcc-outline btn-sm">
                    <i class="bi bi-eye"></i> View
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if ($selectedWeek && !empty($weekResults)): ?>
    <hr class="divider">
    <h2 class="mcc-section-title"><i class="bi bi-trophy-fill"></i> <?= htmlspecialchars($selectedWeek) ?></h2>

    <?php foreach ($weekResults as $catKey => $catData): ?>
        <div class="mcc-card">
            <div class="mcc-card-title"><i class="bi bi-tag-fill"></i> <?= htmlspecialchars($catData['label']) ?></div>

            <?php foreach ($catData['photos'] as $photo): ?>
                <form method="POST" action="/archive.php?week=<?= urlencode($selectedWeek) ?>" class="mb-3">
                    <input type="hidden" name="save_photo" value="1">
                    <input type="hidden" name="archive_id" value="<?= $photo['id'] ?>">
                    <input type="hidden" name="week_label" value="<?= htmlspecialchars($selectedWeek) ?>">
                    <input type="hidden" name="category" value="<?= htmlspecialchars($catKey) ?>">
                    <input type="hidden" name="photo_number" value="<?= $photo['photo_number'] ?>">

                    <div class="archive-photo-row">
                        <div class="archive-photo-num">#<?= $photo['photo_number'] ?></div>
                        <input type="text" name="photographer_name" class="form-control form-control-sm"
                               placeholder="Photographer name"
                               value="<?= htmlspecialchars($photo['photographer_name'] ?? '') ?>">
                        <input type="text" name="photo_title" class="form-control form-control-sm"
                               placeholder="Photo title"
                               value="<?= htmlspecialchars($photo['photo_title'] ?? '') ?>">
                        <button type="submit" class="btn btn-mcc btn-sm">Save</button>
                    </div>
                    <div class="ps-3 mb-1">
                        <span class="archive-points-badge"><i class="bi bi-star-fill text-mcc-accent"></i> <?= $photo['vote_count'] ?> pts</span>
                    </div>
                </form>
            <?php endforeach; ?>

            <hr class="divider">

            <!-- Honours form -->
            <?php $h = $honoursData[$catKey]; ?>
            <form method="POST" action="/archive.php?week=<?= urlencode($selectedWeek) ?>">
                <input type="hidden" name="save_honours" value="1">
                <input type="hidden" name="week_label" value="<?= htmlspecialchars($selectedWeek) ?>">
                <input type="hidden" name="category" value="<?= htmlspecialchars($catKey) ?>">

                <div class="row g-2 mb-2 align-items-end">
                    <div class="col-12"><label class="form-label text-mcc-accent"><i class="bi bi-award-fill"></i> Highly Commended 1</label></div>
                    <div class="col-md-2"><input type="number" name="hc1_num" class="form-control form-control-sm" placeholder="Photo #" value="<?= htmlspecialchars($h['highly_commended_1'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="hc1_name" class="form-control form-control-sm" placeholder="Photographer" value="<?= htmlspecialchars($h['highly_commended_1_name'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="hc1_title" class="form-control form-control-sm" placeholder="Photo Title" value="<?= htmlspecialchars($h['highly_commended_1_title'] ?? '') ?>"></div>
                </div>

                <div class="row g-2 mb-2 align-items-end">
                    <div class="col-12"><label class="form-label text-mcc-accent"><i class="bi bi-award-fill"></i> Highly Commended 2</label></div>
                    <div class="col-md-2"><input type="number" name="hc2_num" class="form-control form-control-sm" placeholder="Photo #" value="<?= htmlspecialchars($h['highly_commended_2'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="hc2_name" class="form-control form-control-sm" placeholder="Photographer" value="<?= htmlspecialchars($h['highly_commended_2_name'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="hc2_title" class="form-control form-control-sm" placeholder="Photo Title" value="<?= htmlspecialchars($h['highly_commended_2_title'] ?? '') ?>"></div>
                </div>

                <div class="row g-2 mb-3 align-items-end">
                    <div class="col-12"><label class="form-label text-mcc-accent"><i class="bi bi-ribbon-fill"></i> Commended</label></div>
                    <div class="col-md-2"><input type="number" name="com_num" class="form-control form-control-sm" placeholder="Photo #" value="<?= htmlspecialchars($h['commended'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="com_name" class="form-control form-control-sm" placeholder="Photographer" value="<?= htmlspecialchars($h['commended_name'] ?? '') ?>"></div>
                    <div class="col-md-4"><input type="text" name="com_title" class="form-control form-control-sm" placeholder="Photo Title" value="<?= htmlspecialchars($h['commended_title'] ?? '') ?>"></div>
                </div>

                <button type="submit" class="btn btn-mcc-outline btn-sm">
                    <i class="bi bi-floppy-fill"></i> Save Honours
                </button>
            </form>
        </div>
    <?php endforeach; ?>
<?php elseif ($selectedWeek): ?>
    <div class="alert-mcc mt-2"><i class="bi bi-info-circle"></i> No results found for "<?= htmlspecialchars($selectedWeek) ?>".</div>
<?php endif; ?>

<?php renderFooter(); ?>

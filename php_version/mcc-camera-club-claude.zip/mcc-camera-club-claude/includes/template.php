<?php
session_start();

require_once __DIR__ . '/db.php';

// Check if member is logged in (PIN entered)
function isMemberLoggedIn() {
    return isset($_SESSION['member_logged_in']) && $_SESSION['member_logged_in'] === true;
}

// Check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// Require member login - redirect to index if not
function requireMemberLogin() {
    if (!isMemberLoggedIn()) {
        header('Location: /index.php');
        exit;
    }
}

// Points map
function pointsForPosition($pos) {
    $map = [1 => 5, 2 => 4, 3 => 3, 4 => 2, 5 => 1];
    return $map[$pos] ?? 0;
}

function renderHeader($title = 'Maguiresbridge Camera Club', $extraHead = '') {
    $loggedIn = isMemberLoggedIn();
    $currentPage = basename($_SERVER['PHP_SELF']);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($title) ?> | MCC Voting</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700&family=Barlow:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/bootstrap-5.3.8-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/bootstrap-icons-1.13.1/bootstrap-icons.min.css">
    <link rel="stylesheet" href="assets/style.css">
    <?= $extraHead ?>
</head>
<body class="">
<div id="top-bar">
    <div class="container-fluid d-flex align-items-center justify-content-between px-3 py-2">
        <div class="brand d-flex align-items-center gap-2">
            <i class="bi bi-camera2 brand-icon"></i>
            <span class="brand-name">Maguiresbridge<span class="brand-accent"> Camera Club</span></span>
        </div>
        <div class="access-tools d-flex gap-2">
            <button class="btn btn-sm btn-outline-secondary" id="contrastToggle" onclick="toggleContrast()">
                <i class="bi bi-circle-half"></i> High Contrast
            </button>
            <button class="btn btn-sm btn-outline-secondary" id="textSizeToggle" onclick="toggleTextSize()">
                <i class="bi bi-fonts"></i> Larger Text
            </button>
        </div>
    </div>
</div>

<?php if ($loggedIn): ?>
<nav class="navbar navbar-expand-md" id="main-nav">
    <div class="container-fluid px-3">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage == 'vote.php' ? 'active' : '' ?>" href="/vote.php">
                        <i class="bi bi-check2-square"></i> Vote
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage == 'tally.php' ? 'active' : '' ?>" href="/tally.php">
                        <i class="bi bi-bar-chart-fill"></i> Live Tally
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage == 'archive.php' ? 'active' : '' ?>" href="/archive.php">
                        <i class="bi bi-archive-fill"></i> Archive
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($currentPage, 'admin') !== false) ? 'active' : '' ?>" href="/admin/index.php">
                        <i class="bi bi-shield-lock-fill"></i> Admin
                    </a>
                </li>
            </ul>
            <a href="/logout.php" class="btn btn-sm btn-logout ms-2">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>
<?php endif; ?>

<main class="container py-4">
<?php
}

function renderFooter() {
?>
</main>

<footer class="py-3 mt-auto">
    <div class="container text-center footer-text">
        <small><i class="bi bi-camera2"></i> Maguiresbridge Camera Club &mdash; Competition Voting System</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/app.js"></script>
</body>
</html>
<?php
}
